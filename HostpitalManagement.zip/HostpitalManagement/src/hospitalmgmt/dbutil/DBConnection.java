
package hospitalmgmt.dbutil;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class DBConnection {
private static Connection conn;
    static {
    try
    {
    Class.forName("oracle.jdbc.OracleDriver");
        conn=DriverManager.getConnection("jdbc:oracle:thin:@//LAPTOP-T657CII0:1521/xe","myhms","student");
        JOptionPane.showMessageDialog(null,"Connection done succesfully...!");
    
    }
    catch(ClassNotFoundException ex)
    {
        JOptionPane.showMessageDialog(null,"Cannot load driver..!"+ex);
    ex.printStackTrace();
    }
    catch(SQLException sqle)
    {
        JOptionPane.showMessageDialog(null,"Problem in Db...!"+sqle);
    sqle.printStackTrace();
    
    }

    } 
    public static Connection getConnection()
    {
    return conn;
    }
    public static void closeConnection()
    {
        
    try{
      if(conn!=null)
        {
        conn.close();
        JOptionPane.showMessageDialog(null,"Connection closed succesfully...!");
    
    }
    }
    catch(SQLException ex1)
    {
        JOptionPane.showMessageDialog(null,"Problem in closing Connection...!");
        ex1.printStackTrace();
    
    }
        
    }
}


