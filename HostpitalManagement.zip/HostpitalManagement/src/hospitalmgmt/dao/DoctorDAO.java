package hospitalmgmt.dao;

import hospitalmgmt.dbutil.DBConnection;
import hospitalmgmt.pojo.DoctorPojo;
import hospitalmgmt.pojo.EmpPojo;
import hospitalmgmt.pojo.UserPojo1;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;

public class DoctorDAO {

 public static ArrayList<String> getUserDetails()throws SQLException
    {
     Connection conn=DBConnection.getConnection();
        String qry="select distinct empid  from users where usertype='DOCTOR' order by empid";
        Statement st=conn.createStatement();
        ResultSet rs=st.executeQuery(qry);
        ArrayList<String> idlist=new ArrayList<>();
        while(rs.next())
        {
        String id=rs.getString(1);
        idlist.add(id);
        }
        return idlist;
    } 
 
   /*public static ArrayList<String> getFindEmp()throws SQLException
    {
        Connection conn=DBConnection.getConnection();
        String qry="select distinct EName from employee where role='DOCTOR'  empid not in (select empid from users where usertype='DOCTOR')";
        Statement st=conn.createStatement();
        ResultSet rs=st.executeQuery(qry);
        ArrayList<String> Empname=new ArrayList<>();
        while(rs.next())
        {
        String name=rs.getString(1);
           // System.out.println("name "+id);
           Empname.add(name);
        }
        return Empname;
     }*/
    
 public static HashMap<String,String> getFindEmp()throws SQLException
    {
        Connection con = DBConnection.getConnection();
        String qry = "select empid,ename from employee where role='DOCTOR'and empid not in (select empid from users where usertype='DOCTOR')";
        Statement st = DBConnection.getConnection().createStatement();
        ResultSet rs = st.executeQuery(qry);
        HashMap<String, String> doctors = new HashMap<>();
        while(rs.next()){
            String id = rs.getString(1);
            String name = rs.getString(2);
            doctors.put(id,name);
        }
        return doctors;
    }

        
        
        
        /*Connection conn=DBConnection.getConnection();
        String qry="select EName , empid from employee where role='DOCTOR' and  empid not in (select empid from users where usertype='DOCTOR')";
        Statement st=conn.createStatement();
        ResultSet rs=st.executeQuery(qry);
        HashMap<String,String> Empname=new HashMap<>();
        while(rs.next())
        {
        String name=rs.getString(1);
        String id=rs.getString(2);
        
           // System.out.println("name "+id);
           Empname.put(name,id);
        }
        return Empname;*/
     
 
    public static String getEmpId(String s)throws SQLException
    {
    /*String eid=null;
    UserPojo1 up =new UserPojo1();
 PreparedStatement ps=DBConnection.getConnection().prepareStatement("select empid from employee where ename=?");
   ps.setString(1, up.getEmpid());
   ResultSet rs=ps.executeQuery();
   if(rs.next())
   {
   eid= rs.getString(1);
   }
 return eid;*/
  PreparedStatement ps = DBConnection.getConnection().prepareStatement("select empid from employee where ename=?");
        ps.setString(1, s);
        ResultSet rs = ps.executeQuery();
        String ename = null;
        if(rs.next()){
            ename = rs.getString(1);
        }
        return ename;
       
    }
 public static boolean getRegisterUsers(UserPojo1 ep)throws SQLException
{
PreparedStatement ps=DBConnection.getConnection().prepareStatement("insert into users values(?,?,?,?,?)");
ps.setString(1,ep.getUserid());
ps.setString(2, ep.getUsername());
ps.setString(3, ep.getEmpid());
ps.setString(4, ep.getPassword());
ps.setString(5,ep.getUsertype());
 int rs=ps.executeUpdate();
 return rs==1;
}
 
 public static boolean getRegisterDoctor(DoctorPojo dp)throws SQLException
{
PreparedStatement ps=DBConnection.getConnection().prepareStatement("insert into doctors values(?,?,?,?,?)");
ps.setString(1,dp.getUserid());
ps.setString(2, dp.getDoctorId());
ps.setString(3, dp.getQualification());
ps.setString(4, dp.getSpecialize());
ps.setString(5, dp.getActive());
 int rs=ps.executeUpdate();
   return rs==1;
}
public static String getNewId()throws SQLException
{
Connection con=DBConnection.getConnection();
Statement st=con.createStatement();
ResultSet rs=st.executeQuery("select max(doctorid) from doctors where active='yes' or active='no'");
int id=1;
rs.next();
 String empid=rs.getString(1);
 int eno=Integer.parseInt(empid.substring(1));
  id=id+eno;

String sr= "d"+id;
  System.out.println(sr);
    return sr;
} 

public static ArrayList<String> getAllDoctorsId()throws SQLException
    {
        ArrayList<String> docId = new ArrayList<>();
        ResultSet rs = DBConnection.getConnection().createStatement().executeQuery("select distinct doctorid from doctors where active='yes'");
        while(rs.next())
        {
            docId.add(rs.getString(1));
        }
        return docId;
    }
 public static boolean RemoveDoctor(String st)throws SQLException
 {
 PreparedStatement ps=DBConnection.getConnection().prepareStatement("update doctors set active='no' where doctorid=?");
ps.setString(1,st);
int rs=ps.executeUpdate();
 return rs==1;
 }
 public static ArrayList<DoctorPojo> getAllDoctor()throws SQLException
{
Connection con=DBConnection.getConnection();
Statement st=con.createStatement();
ResultSet rs=st.executeQuery("select * from Doctors where Active='yes'");
ArrayList<DoctorPojo> EmpList=new ArrayList<>();
while(rs.next())
{ DoctorPojo ep=new DoctorPojo();
ep.setDoctorId(rs.getString(1));
ep.setUserid(rs.getString(2));
ep.setQualification(rs.getString(3));
ep.setSpecialize(rs.getString(4));
EmpList.add(ep);
}
        return EmpList;
}
public static String getDoctord(String id)throws SQLException
{
Connection con=DBConnection.getConnection();
Statement st=con.createStatement();
ResultSet rs=st.executeQuery("select doctorid from doctors where active='yes' and userid=?");
String did=null;
   if(rs.next())
  {
  did=rs.getString(1);
       }
  return did;
 }
 
}