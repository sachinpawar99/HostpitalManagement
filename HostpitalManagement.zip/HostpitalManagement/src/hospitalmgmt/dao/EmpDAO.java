package hospitalmgmt.dao;

import hospitalmgmt.dbutil.DBConnection;
import hospitalmgmt.pojo.EmpPojo;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.TreeMap;

public class EmpDAO {

public static String getNewId()throws SQLException
{
Connection con=DBConnection.getConnection();
Statement st=con.createStatement();
ResultSet rs=st.executeQuery("select max(empid) from employee");
int id=1;
rs.next();
 String empid=rs.getString(1);
 int eno=Integer.parseInt(empid.substring(3));
  id=id+eno;

String sr= "emp"+id;
  System.out.println(sr);
    return sr;
}
public static boolean addEmployee(EmpPojo ep)throws SQLException
{
PreparedStatement ps=DBConnection.getConnection().prepareStatement("insert into Employee values(?,?,?,?)");
ps.setString(1,ep.getEmpid());
ps.setString(2, ep.getEmpname());
ps.setString(3, ep.getJob());
ps.setDouble(4, ep.getSal());

int rs=ps.executeUpdate();
  return rs==1;
 }

public static ArrayList<EmpPojo> getAllEmp()throws SQLException
{
Connection con=DBConnection.getConnection();
Statement st=con.createStatement();
ResultSet rs=st.executeQuery("select * from employee");
ArrayList<EmpPojo> EmpList=new ArrayList<>();
while(rs.next())
{ EmpPojo ep=new EmpPojo();
ep.setEmpid(rs.getString(1));
ep.setEmpname(rs.getString(2));
ep.setJob(rs.getString(3));
ep.setSal(rs.getDouble(4));
EmpList.add(ep);
}
        return EmpList;
}
 public static EmpPojo getFindKey(String id)throws SQLException
 {EmpPojo ep=null;
 PreparedStatement ps=DBConnection.getConnection().prepareStatement("select * from employee where empid=?");
   ps.setString(1, id);
   ResultSet rs=ps.executeQuery();
   if(rs.next())
   {
    ep=new EmpPojo();
ep.setEmpid(rs.getString(1));
ep.setEmpname(rs.getString(2));
ep.setJob(rs.getString(3));
ep.setSal(rs.getDouble(4));
   }
 return ep;
 }
 public static boolean getUpdate(EmpPojo ep)throws Exception
{
 
PreparedStatement ps=DBConnection.getConnection().prepareStatement("update  Employee set ename=?,role=?,sal=? where empid=?");
      ps.setString(1,ep.getEmpname());
       ps.setString(2,ep.getJob());
       ps.setDouble(3,ep.getSal());  
        ps.setString(4,ep.getEmpid());
       int res=ps.executeUpdate();
       return res==1;
}

 public static Boolean DeletedEmp(String eno)throws SQLException
{  int num=0;
     PreparedStatement ps=DBConnection.getConnection().prepareStatement("delete users where empid=?");
       ps.setString(1,eno);
       int rs=ps.executeUpdate();
       if(rs==1||rs==0)
       {
       PreparedStatement ps1=DBConnection.getConnection().prepareStatement("delete employee where empid=?");
       ps1.setString(1,eno);
       num=ps1.executeUpdate();
       }
       return num==1;
}
    
    public static HashMap<String,String> getNonRegisteredRecieptionistList()throws SQLException
    {
        Connection conn=DBConnection.getConnection();
        String qry="select empid,ename from employee where role='RECIEPTIONIST' and empid not in (select empid from users where usertype='RECIEPTIONIST')";
        Statement st=conn.createStatement();
        ResultSet rs=st.executeQuery(qry);
        HashMap<String,String> receptionist=new HashMap<>();
        while(rs.next())
        {
        String id=rs.getString(1);
        String name=rs.getString(2);
           // System.out.println("name "+id);
           receptionist.put(id, name);
        }
        return receptionist;
     }
   public static ArrayList<String> getIdRole()throws SQLException
    {
     Connection conn=DBConnection.getConnection();
        String qry="select distinct empid  from employee order by empid";
        Statement st=conn.createStatement();
        ResultSet rs=st.executeQuery(qry);
        ArrayList<String> idlist=new ArrayList<>();
        while(rs.next())
        {
        String id=rs.getString(1);
        idlist.add(id);
        }
        return idlist;
    }       
 
}
