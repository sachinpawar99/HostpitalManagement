package hospitalmgmt.dao;

import hospitalmgmt.dbutil.DBConnection;
import hospitalmgmt.pojo.UserPojo;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class UserDAO {

public static String validateUser(UserPojo user)throws SQLException
{

  PreparedStatement ps=DBConnection.getConnection().prepareStatement("select username from users where userid=? and password=? and usertype=?");
  ps.setString(1, user.getUid());
  ps.setString(2,user.getPwd());
  ps.setString(3, user.getUtype());
  ResultSet rs=ps.executeQuery();
  String uname=null;
   if(rs.next())
  {
  uname=rs.getString(1);
      System.out.println(rs.getString(1));
   }
  return uname;
  }    
}
